using Avalonia.Controls;
using System;
using ToDoList.Models;
using ToDoList.ViewModels;
using System.Linq;

namespace ToDoList.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
