# To-Do-List

* First HW on VP - "Thread pool"
* Second HW on VP - "Roman numbers"
* Third HW on VP - "Roman numbers operators"
* Forth HW on VP - "Roman numbers calc"
* Fifth HW on VP - "Regex App"
* Sixth HW on VP - "To Do List"
